#Example Exponential - Uniform

Data_Ifix = rcensIfix(rdistrX = rexp, interval_length = 2,
                   param_X = list("rate" = .5),
                   n = 1e02, theta = .9)

## Example with plot in examples_plot/Example_rcensIfix_plot.R

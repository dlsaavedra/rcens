#Example Exponential Cure Fraction p = 0.5

Data = rcuref(rdistrX = rexp, param_X = list("rate" = 1),
              n = 1000, p = 0.5)

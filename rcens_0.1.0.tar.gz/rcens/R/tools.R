## PALEY-ZYGMUND-------
# P(Z> a*E(Z))>=(1-a^2)E(Z)^2/E(Z^2).    Z>=0  y  a in [0,1]

root_x2_p = function(a, b, c){(-b + sqrt(b^2-4*a*c))/(2*a)}
